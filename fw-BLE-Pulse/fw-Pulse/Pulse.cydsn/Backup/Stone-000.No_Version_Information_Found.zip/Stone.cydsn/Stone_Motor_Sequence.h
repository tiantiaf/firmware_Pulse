/* ========================================
 *
 * Tiantian Feng, 2017
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#if !defined(STONE_MOTOR_SEQUENCE_H)
#define STONE_MOTOR_SEQUENCE_H
    

#include <main.h>

#define PERIOD_PER_CYCLE_RUN    64



#endif
/* [] END OF FILE */
